document.getElementById('send-button').addEventListener('click', sendMessage);
document.getElementById('user-input').addEventListener('keypress', function (e) {
  if (e.key === 'Enter') sendMessage();
});

function appendMessage(sender, message) {
  const chatWindow = document.getElementById('chat-window');
  const messageElem = document.createElement('div');
  messageElem.className = `message ${sender.toLowerCase()}`;
  messageElem.innerHTML = `<strong>${sender}:</strong> ${message}`;
  chatWindow.appendChild(messageElem);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

async function sendMessage() {
  const userInput = document.getElementById('user-input');
  const message = userInput.value.trim();
  if (!message) return;

  appendMessage('You', message);
  userInput.value = '';

  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });

    const data = await response.json();

    if (response.ok) {
      appendMessage('SmartVakil', data.message);
    } else {
      appendMessage('SmartVakil', 'Sorry, something went wrong.');
    }
  } catch (error) {
    console.error('Error:', error);
    appendMessage('SmartVakil', 'Sorry, something went wrong.');
  }
}